## First: I will add all the libraries I used in part one 

# Import TensorFlow 

import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_hub as hub
tfds.disable_progress_bar()

# Ignore some warnings that are not relevant (you can remove this if you prefer)

import warnings #
warnings.filterwarnings('ignore')
# TODO: Make all other necessary imports.

import pandas as pd
import numpy as np
import json
import time

import logging
loger_tf = tf.get_logger()
loger_tf.setLevel(logging.ERROR)

# Some other recommended settings:

tfds.disable_progress_bar()


## More for this past 


import argparse, pathlib

from PIL import Image




## idea for parser Argument 



parser = argparse.ArgumentParser()
parser.add_argument('input', action='store', type = str, help ='The input image')  
parser.add_argument('model', action='store', type = str, help= 'The model classifier file')
parser.add_argument('--top_k' , action='store', default = 5, type = int , help = "The top_k class")
parser.add_argument('--category_names', action="store", default = './label_map.json',  type = str , help='Display Json file.')
arg_parser = parser.parse_args()                  
top_k = arg_parser.top_k
    
                        
     # all my identified functins in part ( ( 1 ))                   
                        
# TODO: Create the process_image function

def process_image(image):
    
    image = tf.cast(image, tf.float32)
    
    ## since the image.size equl  ((224 ) so I will use the number 
    
    image = tf.image.resize(image, (224, 224))
    
    image /= 255
    
    image = image.numpy()
    
    return image
                        
                        
                        

# TODO: Create the predict function

def predict(image_path, model, top_k = 5):

    # open image path
    
    imgee = Image.open(image_path)
    
    #  the image convert and process using numpy array
    
    imgee = np.asarray(imgee)
    
    processed_test_image = process_image(imgee)
    
   
    expanded_image = np.expand_dims(processed_test_image, 0)
    
    
    # Now , image prediction using  model
    
    
    predict_image = model(expanded_image)
    
    
    probabilities_image = tf.math.top_k(predict_image, k=top_k).values.numpy().squeeze()
    
    
    labels = list(map(str, tf.math.top_k(predict_image, k=top_k).indices.numpy().squeeze()+np.array([1])))
    classes = [class_names[key].title() for key in labels]

    fig, (ax1, ax2) = plt.subplots(figsize=(10,6),ncols=2)
    
    
    ax1.imshow(processed_test_image)
    
    ax1.set_title('The Processed of our Image : {}'.format(image_path))
    
    ax2.barh(classes, probabilities_image)
    
    ax2.set_title("The Probabilities that associat Top {} Predictions using model".format(top_k))
    
    plt.tight_layout()
    
    plt.show()
    
    return probabilities_image, labels, classes
 
                        
                        ## .................
                        
                        
## reading open file 
                        
with open(arg_parser.category_names, 'r') as f:
                        
    mapping = json.load(f)                        

                        
                          # make predictions .............................
                        
                        
     # Now we can load our  model                       ............
                        
                        
                        
model_keras = tf.keras.models.load_model(arg_parser.model, custom_objects={'KerasLayer':hub.KerasLayer})
                        
probs , labels, classes = predict(arg_parser.input, model_keras, top_k = arg_parser.top_k)                       

           
for image, label, prob in zip(classes,labels,probs):
    print('Predicted class labels are: {}'.format(label) ,'thier probabilities are: {}'.format(prob) , 
          'and names are: {}'.format(image))                 
               